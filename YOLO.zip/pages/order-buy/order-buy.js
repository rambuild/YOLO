
Page({
	data: {
		user: {},
		orderList: [],
		userDefaultAddr: {},
		totalPrice: 0,
	},
	onLoad(options) {
		let orderList = JSON.parse(decodeURIComponent(options.orderList))
		// 计算总价
		let totalPrice = 0
		orderList.forEach(i => {
			totalPrice += parseFloat(i.price) * parseFloat(i.num)
		})
		let user = wx.getStorageSync("user")
		this.setData({
			user,
			orderList,
			totalPrice
		})
	},
	onShow() {
		this.getUserAddr()
	},
	getUserAddr() {
		wx.http({
			url: "getAddress",
			loading: true,
			data: {
				userId: this.data.user.id
			}
		}).then(res => {
			let userDefaultAddr = {}
			res.data.forEach(i => {
				if (i.type == 2) {
					userDefaultAddr = i
				}
			})
			this.setData({
				userDefaultAddr
			})
		})
	},
	confirmPay() {
		wx.showModal({
			title: "提示",
			content: "确认支付？",
			success: res => {
				if (res.confirm) {
					wx.http({
						url: "insertOrder",
						data: {
							userId: this.data.user.id,
							addressId: this.data.userDefaultAddr.id,
							price: this.data.totalPrice
						}
					}).then(res => {
						if (res.code == 200) {
							wx.http({
								url: "prepay",
								data: {
									qorderid: res.data.orderId,
									qgmopenid: this.data.user.openId,
									qsum: this.data.totalPrice
								}
							}).then(res => {
								if (res.code == 200) {
									let data = res.data
									// 调起微信支付
									wx.requestPayment({
										nonceStr: data.nonceStr,
										package: data.package,
										paySign: data.paySign,
										timeStamp: data.timeStamp,
										signType: data.signType,
										appId: data.prepayId,
										success: res => {
											// 支付成功
											if (res.errMsg == "requestPayment:ok") {
												console.log("支付成功")
												wx.switchTab({
													url: "/pages/car/car"
												})
											}
										},
										fail: res => {
											// 支付失败
											console.log("支付失败")
											wx.switchTab({
												url: "/pages/car/car"
											})
										}
									})
								}
							})
						} else {
							wx.showToast({
								title: res.msg,
								icon: "none"
							})
						}
					})
				} else if (res.cancel) {
				}
			}
		})
	},
	selAddr() {
		wx.navigateTo({
			url: "/pages/myAddress/myAddress?action=changeAddr"
		})
	}
})
