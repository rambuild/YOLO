//Component Object
Component({
    options:{
		multipleSlots:true
	},
    properties: {
        // 名称
        name:{
           type:String,
           value:''
        },
        imgsrc:{
            type:String,
            value:''
        },
        // 样式
        imgStyle:{
            type:String,
            value:''  
        },
        titleStyle:{
           type:String,
           value:''
       },

    },
    data: {

    },
    methods: {
        
    },
    created: function(){

    },
    attached: function(){

    },
    ready: function(){

    },
    moved: function(){

    },
    detached: function(){

    },
});